let currentPaymentData = null;
let timerInterval = null;
let sseSource = null;
let hasRedirectedToSuccess = false;

function getSuccessUrl() {
  const candidate = new URLSearchParams(window.location.search).get('success_url');
  if (!candidate) return null;

  try {
    const url = new URL(candidate);
    return ['http:', 'https:'].includes(url.protocol) ? url.toString() : null;
  } catch {
    return null;
  }
}

function getOrderIdFromUrl() {
  const pathParts = window.location.pathname.split('/');
  if (pathParts.length > 2 && pathParts[1] === 'checkout') {
    return pathParts[2];
  }
  const params = new URLSearchParams(window.location.search);
  return params.get('order_id') || params.get('id');
}

async function initCheckout() {
  const orderId = getOrderIdFromUrl();
  if (!orderId) {
    document.getElementById('loadingState').innerHTML = `<p style="color: var(--danger);">Error: No Order ID provided in URL.</p>`;
    return;
  }

  try {
    const res = await fetch(`/api/payments/${orderId}`);
    const data = await res.json();

    if (!data.success || !data.payment) {
      document.getElementById('loadingState').innerHTML = `<p style="color: var(--danger);">Order not found or expired.</p>`;
      return;
    }

    currentPaymentData = data.payment;
    renderPaymentDetails(data.payment);

    // Setup SSE connection for real-time order update
    setupSse(orderId);

  } catch (err) {
    console.error('Failed to load payment details:', err);
    document.getElementById('loadingState').innerHTML = `<p style="color: var(--danger);">Error loading payment information.</p>`;
  }
}

function renderPaymentDetails(p) {
  document.getElementById('loadingState').style.display = 'none';
  document.getElementById('paymentDetails').style.display = 'block';

  document.getElementById('orderIdText').textContent = p.order_id;
  document.getElementById('payableAmountText').textContent = p.payableAmountFormatted;
  document.getElementById('exactAmountAlertText').textContent = p.payableAmountFormatted;
  document.getElementById('baseAmountText').textContent = p.baseAmountFormatted;
  document.getElementById('verificationAmountBreakdown').textContent = `+ ₹${p.verificationAmountRupees.toFixed(2)}`;
  setPaymentAppLinks(p.upi_url, p.order_id);

  updateStatusBadge(p.status);

  // Start countdown if pending
  if (p.status === 'PENDING') {
    startCountdown(p.expires_at);
  } else {
    document.getElementById('countdownTimer').textContent = '00:00';
  }
}

function setPaymentAppLinks(upiUrl, orderId) {
  const upi = new URL(upiUrl);
  const params = {
    pa: upi.searchParams.get('pa') || '',
    pn: upi.searchParams.get('pn') || '',
    am: upi.searchParams.get('am') || '',
    cu: 'INR',
    tn: `Order ${orderId}`
  };
  const platform = getMobilePlatform();
  const standardQuery = new URLSearchParams(params).toString();

  if (platform === 'android') {
    document.getElementById('phonepe').href = generatePhonePeNativeLink(params.am, params.pn, params.pa, params.tn);
    document.getElementById('gpay').href = `tez://upi/pay?${standardQuery}`;

    const paytmParams = new URLSearchParams({
      ...params,
      tr: orderId,
      featuretype: 'money_transfer'
    });
    document.getElementById('paytm').href = `paytmmp://cash_wallet?${paytmParams.toString()}`;
  } else if (platform === 'ios') {
    document.getElementById('phonepe').href = `phonepe://upi//pay?${standardQuery}`;
    document.getElementById('gpay').href = `gpay://upi/pay?${standardQuery}`;
    document.getElementById('paytm').href = `paytmmp://pay?${standardQuery}`;
  } else {
    document.getElementById('phonepe').href = `upi://pay?${standardQuery}`;
    document.getElementById('gpay').href = `upi://pay?${standardQuery}`;
    document.getElementById('paytm').href = `upi://pay?${standardQuery}`;
  }

  document.getElementById('bhim').href = `upi://pay?${standardQuery}`;
  document.getElementById('other-upi').href = `upi://pay?${standardQuery}`;
}

function getMobilePlatform() {
  const userAgent = navigator.userAgent || '';
  if (/android/i.test(userAgent)) return 'android';
  if (/iPhone|iPad|iPod/i.test(userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1)) {
    return 'ios';
  }
  return 'other';
}

function generatePhonePeNativeLink(amount, merchantName, vpa, note = 'Payment') {
  const payload = {
    p2pPaymentCheckoutParams: {
      checkoutType: 'COLLECT',
      initialAmount: amount,
      note: {
        type: 'text',
        message: note
      },
      supportedInstruments: -1
    },
    contact: {
      type: 'EXTERNAL_MERCHANT',
      name: merchantName,
      vpa
    }
  };

  const encodedPayload = btoa(unescape(encodeURIComponent(JSON.stringify(payload))));
  return `phonepe://native?data=${encodeURIComponent(encodedPayload)}&id=p2ppayment`;
}

function updateStatusBadge(status) {
  const badge = document.getElementById('statusBadge');
  const gateway = document.getElementById('gateway');
  badge.textContent = status;
  badge.className = 'footer';
  gateway.classList.toggle('expired', status === 'EXPIRED');
  gateway.classList.toggle('payment-complete', status === 'PAID');

  if (status === 'PENDING') {
    badge.textContent = 'Waiting for payment confirmation';
  } else if (status === 'PAID') {
    badge.classList.add('badge-paid');
    badge.textContent = 'Payment successful';
    showPaymentSuccessView();
    const successUrl = getSuccessUrl();
    if (successUrl && !hasRedirectedToSuccess) {
      hasRedirectedToSuccess = true;
      window.location.assign(successUrl);
    }
  } else if (status === 'EXPIRED') {
    badge.classList.add('badge-expired');
    badge.textContent = 'Payment session expired';
    showExpiredView();
  } else {
    badge.classList.add(`badge-${status.toLowerCase()}`);
    badge.textContent = `Payment ${status.toLowerCase()}`;
    disablePaymentOptions();
  }
}

function startCountdown(expiresAtIso) {
  if (timerInterval) clearInterval(timerInterval);

  const expiresTime = new Date(expiresAtIso).getTime();

  function tick() {
    const now = new Date().getTime();
    const diff = Math.max(0, Math.floor((expiresTime - now) / 1000));

    const minutes = Math.floor(diff / 60);
    const seconds = diff % 60;
    const formatted = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

    const timerEl = document.getElementById('countdownTimer');
    timerEl.textContent = formatted;

    if (diff <= 0) {
      clearInterval(timerInterval);
      updateStatusBadge('EXPIRED');
    }
  }

  tick();
  timerInterval = setInterval(tick, 1000);
}

function setupSse(orderId) {
  if (sseSource) sseSource.close();

  sseSource = new EventSource(`/api/sse/payments/${orderId}`);

  sseSource.addEventListener('order_update', (event) => {
    const data = JSON.parse(event.data);
    console.log('[SSE] Order Update Event:', data);
    if (data.status === 'PAID') {
      if (timerInterval) clearInterval(timerInterval);
      updateStatusBadge('PAID');
      showToast('Payment verified successfully!');
    }
  });

  sseSource.onerror = (err) => {
    console.warn('[SSE] Connection error, falling back to polling...', err);
    // Poll every 4 seconds as fallback
    setTimeout(() => pollPaymentStatus(orderId), 4000);
  };
}

async function pollPaymentStatus(orderId) {
  try {
    const res = await fetch(`/api/payments/${orderId}`);
    const data = await res.json();
    if (data.success && data.payment) {
      if (data.payment.status !== 'PENDING') {
        updateStatusBadge(data.payment.status);
      }
    }
  } catch (err) {
    console.error('Polling error:', err);
  }
}

function showPaymentSuccessView() {
  disablePaymentOptions();
}

function showExpiredView() {
  disablePaymentOptions();
}

function disablePaymentOptions() {
  document.querySelectorAll('#paymentOptions .pay-btn').forEach((button) => {
    button.removeAttribute('href');
    button.setAttribute('aria-disabled', 'true');
  });
}

function copyUpiLink() {
  if (!currentPaymentData) return;
  navigator.clipboard.writeText(currentPaymentData.upi_url);
  showToast('UPI Link copied to clipboard!');
}

function showToast(msg) {
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = msg;
  document.body.appendChild(toast);

  setTimeout(() => toast.remove(), 3000);
}

document.addEventListener('DOMContentLoaded', initCheckout);
