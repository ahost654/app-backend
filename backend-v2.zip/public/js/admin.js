let activeTab = 'payments';

document.addEventListener('DOMContentLoaded', () => {
  loadStats();
  loadPayments();
  setupSse();
});

function switchTab(tabName) {
  activeTab = tabName;
  document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
  document.querySelectorAll('section').forEach(sec => sec.style.display = 'none');

  const btnIndex = ['payments', 'devices', 'transactions', 'simulator', 'logs'].indexOf(tabName);
  if (btnIndex >= 0) {
    document.querySelectorAll('.nav-btn')[btnIndex].classList.add('active');
  }

  document.getElementById(`tab-${tabName}`).style.display = 'block';

  if (tabName === 'payments') loadPayments();
  if (tabName === 'devices') loadDevices();
  if (tabName === 'transactions') loadTransactions();
  if (tabName === 'logs') loadLogs();
}

async function loadStats() {
  try {
    const res = await fetch('/api/admin/stats');
    const data = await res.json();
    if (data.success) {
      const s = data.stats;
      document.getElementById('statRevenue').textContent = `₹${s.totalRevenueRupees}`;
      document.getElementById('statPaid').textContent = s.paidPayments;
      document.getElementById('statPending').textContent = s.pendingPayments;
      document.getElementById('statExpired').textContent = s.expiredPayments;
      document.getElementById('statDevices').textContent = s.activeDevices;
    }
  } catch (err) {
    console.error('Failed to load stats:', err);
  }
}

async function handleCreatePayment(e) {
  e.preventDefault();
  const amount = document.getElementById('baseAmount').value;
  const orderId = document.getElementById('customOrderId').value;
  const note = document.getElementById('paymentNote').value;

  try {
    const res = await fetch('/api/payments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount, orderId: orderId.trim() || undefined, note: note.trim() || undefined })
    });

    const data = await res.json();
    if (data.success && data.payment) {
      document.getElementById('createPaymentForm').reset();
      loadStats();
      loadPayments();
      showCreatedModal(data.payment);
    } else {
      alert(`Error: ${data.error || 'Failed to create payment request'}`);
    }
  } catch (err) {
    alert(`Error: ${err.message}`);
  }
}

function showCreatedModal(p) {
  const checkoutUrl = `${window.location.origin}/checkout/${p.order_id}`;
  const modalBody = document.getElementById('modalBody');
  modalBody.innerHTML = `
    <div style="text-align: center;">
      <div style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 4px;">Order ID: <strong style="color:white;">${p.order_id}</strong></div>
      <div style="font-family: var(--font-heading); font-size: 2.2rem; font-weight: 800; color: var(--success);">${p.payableAmountFormatted}</div>
      <p style="font-size: 0.8rem; color: var(--warning); margin-bottom: 12px;">Includes decimal verification value of ₹${p.verificationAmountRupees.toFixed(2)}</p>

      <div style="background: white; padding: 12px; border-radius: 8px; display: inline-block; margin-bottom: 16px;">
        <img src="${p.qrCodeDataUrl}" style="width: 180px; height: 180px;" alt="QR Code">
      </div>

      <div class="form-group" style="margin-bottom: 16px; text-align: left;">
        <label>Customer Checkout Link:</label>
        <input type="text" readonly value="${checkoutUrl}" class="form-input" id="checkoutUrlInput">
      </div>

      <div class="btn-group">
        <button class="btn" onclick="navigator.clipboard.writeText('${checkoutUrl}'); alert('Checkout link copied!');">📋 Copy Checkout Link</button>
        <a class="btn btn-secondary" href="${checkoutUrl}" target="_blank">🔗 Open Checkout Page</a>
      </div>
    </div>
  `;
  document.getElementById('paymentModal').style.display = 'flex';
}

async function loadPayments() {
  const status = document.getElementById('statusFilter').value;
  const tbody = document.getElementById('paymentsTableBody');

  try {
    const res = await fetch(`/api/admin/payments?status=${status}`);
    const data = await res.json();

    if (!data.success || !data.payments.length) {
      tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-muted);">No payment requests found.</td></tr>`;
      return;
    }

    tbody.innerHTML = data.payments.map(p => `
      <tr>
        <td><strong style="color: white;">${p.order_id}</strong></td>
        <td>${p.baseAmountFormatted}</td>
        <td><strong style="color: var(--success);">${p.payableAmountFormatted}</strong></td>
        <td><span class="badge badge-${p.status.toLowerCase()}">${p.status}</span></td>
        <td>${new Date(p.created_at).toLocaleTimeString()}</td>
        <td>${new Date(p.expires_at).toLocaleTimeString()}</td>
        <td>
          <button class="btn btn-secondary" style="padding: 4px 8px; font-size: 0.8rem;" onclick="viewPaymentDetails('${p.order_id}')">🔍 Details</button>
          ${p.status === 'PENDING' ? `<button class="btn btn-danger" style="padding: 4px 8px; font-size: 0.8rem;" onclick="cancelPayment('${p.order_id}')">✕ Cancel</button>` : ''}
        </td>
      </tr>
    `).join('');
  } catch (err) {
    console.error('Failed to load payments:', err);
    tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--danger);">Error loading payment requests.</td></tr>`;
  }
}

async function viewPaymentDetails(orderId) {
  try {
    const res = await fetch(`/api/admin/payments/${orderId}`);
    const data = await res.json();
    if (!data.success || !data.payment) return;

    const p = data.payment;
    const t = data.transaction;
    const modalBody = document.getElementById('modalBody');

    modalBody.innerHTML = `
      <div style="font-size: 0.9rem;">
        <table style="width: 100%; border: none;">
          <tr><td><strong>Order ID:</strong></td><td>${p.order_id}</td></tr>
          <tr><td><strong>Base Amount:</strong></td><td>${p.baseAmountFormatted}</td></tr>
          <tr><td><strong>Verification Decimal:</strong></td><td>₹${p.verificationAmountRupees.toFixed(2)}</td></tr>
          <tr><td><strong>Payable Amount:</strong></td><td><strong style="color:var(--success);">${p.payableAmountFormatted}</strong></td></tr>
          <tr><td><strong>Status:</strong></td><td><span class="badge badge-${p.status.toLowerCase()}">${p.status}</span></td></tr>
          <tr><td><strong>Created At:</strong></td><td>${new Date(p.created_at).toLocaleString()}</td></tr>
          <tr><td><strong>Expires At:</strong></td><td>${new Date(p.expires_at).toLocaleString()}</td></tr>
          <tr><td><strong>Paid At:</strong></td><td>${p.paid_at ? new Date(p.paid_at).toLocaleString() : 'N/A'}</td></tr>
        </table>

        <hr style="border-color: var(--border-color); margin: 16px 0;">
        <h4 style="color: var(--primary); margin-bottom: 8px;">📲 Linked SMS Transaction Info</h4>
        ${t ? `
          <table style="width: 100%; border: none;">
            <tr><td><strong>RRN #:</strong></td><td>${t.rrn || 'N/A'}</td></tr>
            <tr><td><strong>UPI Reference:</strong></td><td>${t.upi_reference || 'N/A'}</td></tr>
            <tr><td><strong>Sender:</strong></td><td>${t.sender || 'N/A'}</td></tr>
            <tr><td><strong>Reporting Device:</strong></td><td>${t.device_name || 'N/A'}</td></tr>
            <tr><td><strong>Received At:</strong></td><td>${new Date(t.received_at).toLocaleString()}</td></tr>
            <tr><td colspan="2"><strong>Raw SMS:</strong><br><pre style="background: rgba(15,23,42,0.9); padding: 8px; border-radius: 4px; font-size: 0.75rem; white-space: pre-wrap; margin-top: 4px; color: var(--text-muted);">${t.raw_sms}</pre></td></tr>
          </table>
        ` : `<p style="color: var(--text-muted);">No SMS transaction matched yet.</p>`}
      </div>
    `;

    document.getElementById('paymentModal').style.display = 'flex';
  } catch (err) {
    alert('Error fetching payment details.');
  }
}

async function cancelPayment(orderId) {
  if (!confirm(`Cancel pending payment request ${orderId}?`)) return;

  try {
    const res = await fetch(`/api/admin/payments/${orderId}/cancel`, { method: 'POST' });
    const data = await res.json();
    if (data.success) {
      loadStats();
      loadPayments();
    } else {
      alert(data.message || 'Failed to cancel payment.');
    }
  } catch (err) {
    alert(err.message);
  }
}

async function loadDevices() {
  const tbody = document.getElementById('devicesTableBody');
  try {
    const res = await fetch('/api/admin/devices');
    const data = await res.json();

    if (!data.success || !data.devices.length) {
      tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--text-muted);">No Android devices registered yet. Enter the pairing code in your phone app to connect.</td></tr>`;
      return;
    }

    tbody.innerHTML = data.devices.map(d => `
      <tr>
        <td><code style="font-size: 0.8rem; color: var(--text-dim);">${d.id}</code></td>
        <td><strong style="color: white;">📱 ${d.device_name}</strong></td>
        <td>${new Date(d.created_at).toLocaleString()}</td>
        <td>${d.last_seen ? new Date(d.last_seen).toLocaleString() : 'Never'}</td>
        <td>${d.is_active ? `<span class="badge badge-paid">ACTIVE</span>` : `<span class="badge badge-failed">REVOKED</span>`}</td>
        <td>
          ${d.is_active ? `<button class="btn btn-danger" style="padding: 4px 8px; font-size: 0.8rem;" onclick="revokeDevice('${d.id}')">Revoke Token</button>` : 'Revoked'}
        </td>
      </tr>
    `).join('');
  } catch (err) {
    console.error('Failed to load devices:', err);
  }
}

async function revokeDevice(id) {
  if (!confirm('Revoke this device? It will be logged out and unable to send SMS transactions until re-paired.')) return;
  try {
    const res = await fetch(`/api/admin/devices/${id}/revoke`, { method: 'POST' });
    const data = await res.json();
    if (data.success) {
      loadStats();
      loadDevices();
    }
  } catch (err) {
    alert(err.message);
  }
}

async function loadTransactions() {
  const tbody = document.getElementById('transactionsTableBody');
  try {
    const res = await fetch('/api/admin/transactions');
    const data = await res.json();

    if (!data.success || !data.transactions.length) {
      tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; color: var(--text-muted);">No SMS transactions received yet.</td></tr>`;
      return;
    }

    tbody.innerHTML = data.transactions.map(t => `
      <tr>
        <td>${new Date(t.received_at).toLocaleTimeString()}</td>
        <td><strong style="color: var(--success);">₹${(t.amount / 100).toFixed(2)}</strong></td>
        <td><code>${t.rrn || 'N/A'}</code></td>
        <td><code>${t.upi_reference || 'N/A'}</code></td>
        <td>${t.sender || 'Bank'}</td>
        <td>${t.matched_order_id ? `<span class="badge badge-paid">ORDER ${t.matched_order_id}</span>` : `<span class="badge badge-expired">UNMATCHED</span>`}</td>
        <td>${t.device_name || 'System'}</td>
        <td style="max-width: 250px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 0.75rem; color: var(--text-muted);" title="${t.raw_sms}">${t.raw_sms}</td>
      </tr>
    `).join('');
  } catch (err) {
    console.error('Failed to load transactions:', err);
  }
}

async function handleSimulateSms(e) {
  e.preventDefault();
  const rawSms = document.getElementById('rawSmsInput').value;

  try {
    const res = await fetch('/api/admin/simulate-sms', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ raw_sms: rawSms })
    });

    const data = await res.json();
    const resultCard = document.getElementById('simulationResult');
    const resultTitle = document.getElementById('simResultTitle');
    const resultJson = document.getElementById('simResultJson');

    resultCard.style.display = 'block';
    resultTitle.textContent = data.matched ? '✅ MATCHED & VERIFIED' : (data.isDuplicate ? '⚠️ DUPLICATE SMS DETECTED' : 'ℹ️ PROCESSED (UNMATCHED)');
    resultTitle.style.color = data.matched ? 'var(--success)' : (data.isDuplicate ? 'var(--warning)' : 'var(--text-muted)');
    resultJson.textContent = JSON.stringify(data, null, 2);

    loadStats();
    loadPayments();
    loadTransactions();
  } catch (err) {
    alert(`Simulation error: ${err.message}`);
  }
}

function insertSampleSms(type) {
  const samples = {
    1: "Rs. 100.37 received on 01-10-2026 13:14:49 for BQR-UPI/0373270109100116100020085363087/10011@AXISBANK. RRN#663857923727 - Worldline India",
    2: "Rs. 250.82 received on 01-10-2026 14:51:11 for BQR-UPI/T2609281451096371766822/codeffi@axl. RRN#904196642816 - Worldline India",
    3: "Dear Customer, Account XX123 credited with Rs 500.14 on 01-Oct-26 by UPI Ref no 502524986862."
  };
  document.getElementById('rawSmsInput').value = samples[type] || '';
}

async function loadLogs() {
  const tbody = document.getElementById('logsTableBody');
  try {
    const res = await fetch('/api/admin/logs');
    const data = await res.json();

    if (!data.success || !data.logs.length) {
      tbody.innerHTML = `<tr><td colspan="3" style="text-align: center; color: var(--text-muted);">No audit logs found.</td></tr>`;
      return;
    }

    tbody.innerHTML = data.logs.map(l => `
      <tr>
        <td>${new Date(l.created_at).toLocaleString()}</td>
        <td><strong style="color: var(--primary);">${l.action}</strong></td>
        <td><code style="font-size: 0.8rem; color: var(--text-muted);">${l.details}</code></td>
      </tr>
    `).join('');
  } catch (err) {
    console.error('Failed to load logs:', err);
  }
}

function closeModal() {
  document.getElementById('paymentModal').style.display = 'none';
}

function copyPairingCode() {
  const code = document.getElementById('pairingCodeDisplay').textContent;
  navigator.clipboard.writeText(code);
  alert('Pairing code copied!');
}

function setupSse() {
  const source = new EventSource('/api/sse/events');
  source.addEventListener('transaction', (event) => {
    console.log('[SSE Admin] Transaction event:', event.data);
    loadStats();
    if (activeTab === 'payments') loadPayments();
    if (activeTab === 'transactions') loadTransactions();
  });
}
