import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';

const envPath = path.resolve(process.cwd(), '.env');
dotenv.config({ path: envPath, override: true });

export const config = {
  port: parseInt(process.env.PORT || '3000', 10),
  merchantUpiId: process.env.MERCHANT_UPI_ID || '10011@AXISBANK',
  merchantName: process.env.MERCHANT_NAME || 'AxisBank',
  expirationMinutes: parseInt(process.env.EXPIRATION_MINUTES || '5', 10),
  dbPath: process.env.DB_PATH || './upi_verifier.db',
  pairingSecret: process.env.PAIRING_SECRET || '123456',
  nodeEnv: process.env.NODE_ENV || 'development',
};

export function getActiveMerchantUpiId(): string {
  try {
    const Database = require('better-sqlite3');
    const dbPath = path.resolve(config.dbPath);
    if (fs.existsSync(dbPath)) {
      const db = new Database(dbPath);
      const row = db.prepare(`SELECT value FROM system_settings WHERE key = 'merchant_upi_id'`).get() as any;
      if (row && row.value && row.value.trim()) {
        return row.value.trim();
      }
    }
  } catch (e) {
    // Fallback to env config
  }
  return config.merchantUpiId;
}

export function getActiveMerchantName(): string {
  try {
    const Database = require('better-sqlite3');
    const dbPath = path.resolve(config.dbPath);
    if (fs.existsSync(dbPath)) {
      const db = new Database(dbPath);
      const row = db.prepare(`SELECT value FROM system_settings WHERE key = 'merchant_name'`).get() as any;
      if (row && row.value && row.value.trim()) {
        return row.value.trim();
      }
    }
  } catch (e) {
    // Fallback to env config
  }
  return config.merchantName;
}
