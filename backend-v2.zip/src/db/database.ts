import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';
import { config } from '../config';

const dbPath = path.resolve(config.dbPath);

console.log(`[Database] Connecting to SQLite database at: ${dbPath}`);

export const db = new Database(dbPath, {
  // verbose: console.log
});

// Enable PRAGMA settings for performance and integrity
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Initialize tables from schema.sql
const possibleSchemaPaths = [
  path.join(__dirname, 'schema.sql'),
  path.join(__dirname, '../src/db/schema.sql'),
  path.join(process.cwd(), 'src/db/schema.sql'),
  path.join(process.cwd(), 'dist/db/schema.sql')
];

let schemaSql: string | null = null;
for (const p of possibleSchemaPaths) {
  if (fs.existsSync(p)) {
    schemaSql = fs.readFileSync(p, 'utf8');
    break;
  }
}

if (schemaSql) {
  db.exec(schemaSql);
  console.log('[Database] Schema initialized successfully.');
} else {
  console.warn('[Database] Warning: schema.sql file not found.');
}

export default db;
