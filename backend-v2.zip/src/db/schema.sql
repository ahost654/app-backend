CREATE TABLE IF NOT EXISTS payment_requests (
    id TEXT PRIMARY KEY,
    order_id TEXT UNIQUE NOT NULL,
    base_amount INTEGER NOT NULL,            -- In integer paise (e.g. 10000 for Rs.100.00)
    verification_amount INTEGER NOT NULL,    -- In integer paise (e.g. 37 for Rs.0.37)
    payable_amount INTEGER NOT NULL,         -- In integer paise (e.g. 10037 for Rs.100.37)
    upi_url TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('PENDING', 'PAID', 'EXPIRED', 'FAILED', 'CANCELLED')),
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    paid_at TEXT,
    transaction_id TEXT,
    FOREIGN KEY (transaction_id) REFERENCES transactions(id)
);

CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    amount INTEGER NOT NULL,                 -- In integer paise
    transaction_date TEXT NOT NULL,          -- YYYY-MM-DD
    transaction_time TEXT NOT NULL,          -- HH:MM:SS
    rrn TEXT,
    upi_reference TEXT,
    sender TEXT,
    raw_sms TEXT NOT NULL,
    received_at TEXT NOT NULL,
    matched_payment_id TEXT,
    device_id TEXT,
    is_duplicate INTEGER DEFAULT 0,
    FOREIGN KEY (matched_payment_id) REFERENCES payment_requests(id),
    FOREIGN KEY (device_id) REFERENCES devices(id)
);

CREATE TABLE IF NOT EXISTS devices (
    id TEXT PRIMARY KEY,
    device_name TEXT NOT NULL,
    device_token_hash TEXT UNIQUE NOT NULL,
    created_at TEXT NOT NULL,
    last_seen TEXT,
    is_active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS system_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id TEXT PRIMARY KEY,
    action TEXT NOT NULL,
    details TEXT NOT NULL,
    created_at TEXT NOT NULL
);

-- Performance & Lookup Indexes
CREATE INDEX IF NOT EXISTS idx_payment_active ON payment_requests(status, payable_amount, expires_at);
CREATE INDEX IF NOT EXISTS idx_payment_order_id ON payment_requests(order_id);
CREATE INDEX IF NOT EXISTS idx_txn_rrn ON transactions(rrn);
CREATE INDEX IF NOT EXISTS idx_txn_upi_ref ON transactions(upi_reference);
CREATE INDEX IF NOT EXISTS idx_txn_amount_date ON transactions(amount, transaction_date);
CREATE INDEX IF NOT EXISTS idx_device_token ON devices(device_token_hash);
