import express, { Request, Response } from 'express';
import cors from 'cors';
import path from 'path';
import { config } from './config';
import { apiRouter } from './routes/api';
import { adminRouter } from './routes/admin';
import { sseRouter } from './routes/sse';
import { PaymentService } from './services/paymentService';

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static web app (Admin & Checkout UIs)
app.use(express.static(path.join(__dirname, '../public')));

// Mount Routers
app.use('/api', apiRouter);
app.use('/api/admin', adminRouter);
app.use('/api/sse', sseRouter);

// Specific page routing helpers
app.get('/checkout/:orderId', (req: Request, res: Response) => {
  res.sendFile(path.join(__dirname, '../public/checkout.html'));
});

app.get('/admin', (req: Request, res: Response) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Periodic Expiration Cron Worker (every 10 seconds)
setInterval(() => {
  try {
    PaymentService.expirePendingOrders();
  } catch (err) {
    console.error('[Cron] Error expiring pending orders:', err);
  }
}, 10000);

// Global Error Handler
app.use((err: any, req: Request, res: Response, next: any) => {
  console.error('[Server Error]', err);
  res.status(500).json({ error: err.message || 'Internal Server Error' });
});

// Start Server
const server = app.listen(config.port, () => {
  console.log(`=======================================================`);
  console.log(`🚀 UPI Payment Verification System Backend Running!`);
  console.log(`📍 Local URL:     http://localhost:${config.port}`);
  console.log(`👑 Admin Panel:   http://localhost:${config.port}/admin`);
  console.log(`💳 Merchant UPI:  ${config.merchantUpiId}`);
  console.log(`⏱️ Order Expiry:  ${config.expirationMinutes} Minutes`);
  console.log(`🔑 Pairing Code:  ${config.pairingSecret}`);
  console.log(`=======================================================`);
});

export default app;
