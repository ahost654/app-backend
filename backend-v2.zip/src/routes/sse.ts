import { Router, Request, Response } from 'express';
import { sseEvents } from '../services/matchingService';

export const sseRouter = Router();

/**
 * GET /api/sse/events
 * Real-time event stream for Admin Dashboard and live checkout updates.
 */
sseRouter.get('/events', (req: Request, res: Response): void => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('Access-Control-Allow-Origin', '*');

  res.write('retry: 3000\n\n');
  res.write(`data: ${JSON.stringify({ type: 'CONNECTED', timestamp: new Date().toISOString() })}\n\n`);

  const onTransactionProcessed = (data: any) => {
    res.write(`event: transaction\ndata: ${JSON.stringify(data)}\n\n`);
  };

  sseEvents.on('transaction_processed', onTransactionProcessed);

  req.on('close', () => {
    sseEvents.removeListener('transaction_processed', onTransactionProcessed);
  });
});

/**
 * GET /api/sse/payments/:orderId
 * Specific stream for a single customer checkout order.
 */
sseRouter.get('/payments/:orderId', (req: Request, res: Response): void => {
  const orderId = req.params.orderId;

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('Access-Control-Allow-Origin', '*');

  res.write('retry: 3000\n\n');
  res.write(`data: ${JSON.stringify({ type: 'ORDER_LISTENING', orderId })}\n\n`);

  const onOrderUpdated = (data: any) => {
    res.write(`event: order_update\ndata: ${JSON.stringify(data)}\n\n`);
  };

  const eventName = `order_updated:${orderId}`;
  sseEvents.on(eventName, onOrderUpdated);

  req.on('close', () => {
    sseEvents.removeListener(eventName, onOrderUpdated);
  });
});
