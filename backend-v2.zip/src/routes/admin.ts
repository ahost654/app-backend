import { Router, Request, Response } from 'express';
import { PaymentService } from '../services/paymentService';
import { DeviceService } from '../services/deviceService';
import { MatchingService } from '../services/matchingService';
import { db } from '../db/database';

export const adminRouter = Router();

/**
 * GET /api/admin/stats
 * Dashboard summary metrics.
 */
adminRouter.get('/stats', (req: Request, res: Response): void => {
  try {
    PaymentService.expirePendingOrders();

    const totalStmt = db.prepare(`SELECT COUNT(*) as count FROM payment_requests`);
    const paidStmt = db.prepare(`SELECT COUNT(*) as count, COALESCE(SUM(payable_amount), 0) as total_revenue FROM payment_requests WHERE status = 'PAID'`);
    const pendingStmt = db.prepare(`SELECT COUNT(*) as count FROM payment_requests WHERE status = 'PENDING'`);
    const expiredStmt = db.prepare(`SELECT COUNT(*) as count FROM payment_requests WHERE status = 'EXPIRED'`);
    const deviceCountStmt = db.prepare(`SELECT COUNT(*) as count FROM devices WHERE is_active = 1`);
    const txnCountStmt = db.prepare(`SELECT COUNT(*) as count FROM transactions`);

    const total = (totalStmt.get() as any).count;
    const paidRow = paidStmt.get() as any;
    const pending = (pendingStmt.get() as any).count;
    const expired = (expiredStmt.get() as any).count;
    const activeDevices = (deviceCountStmt.get() as any).count;
    const totalTransactions = (txnCountStmt.get() as any).count;

    res.json({
      success: true,
      stats: {
        totalPayments: total,
        paidPayments: paidRow.count,
        pendingPayments: pending,
        expiredPayments: expired,
        totalRevenueRupees: (paidRow.total_revenue / 100).toFixed(2),
        activeDevices,
        totalTransactions
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch dashboard stats.' });
  }
});

/**
 * GET /api/admin/payments
 * List payment requests.
 */
adminRouter.get('/payments', async (req: Request, res: Response): Promise<void> => {
  try {
    const status = typeof req.query.status === 'string' ? req.query.status : undefined;
    const limit = parseInt(typeof req.query.limit === 'string' ? req.query.limit : '100', 10);
    const payments = await PaymentService.listPaymentRequests(status, limit);
    res.json({ success: true, payments });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch payments.' });
  }
});

/**
 * GET /api/admin/payments/:id
 * Detailed payment request info (including linked raw SMS, RRN, device info).
 */
adminRouter.get('/payments/:id', async (req: Request, res: Response): Promise<void> => {
  try {
    const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
    const payment = await PaymentService.getPaymentRequest(id);

    if (!payment) {
      res.status(404).json({ error: 'Payment request not found.' });
      return;
    }

    let transactionInfo = null;
    if (payment.transaction_id) {
      const stmt = db.prepare(`
        SELECT t.*, d.device_name 
        FROM transactions t 
        LEFT JOIN devices d ON t.device_id = d.id 
        WHERE t.id = ?
      `);
      transactionInfo = stmt.get(payment.transaction_id);
    }

    res.json({
      success: true,
      payment,
      transaction: transactionInfo
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch payment details.' });
  }
});

/**
 * POST /api/admin/payments/:id/cancel
 * Manually cancels a pending payment request.
 */
adminRouter.post('/payments/:id/cancel', (req: Request, res: Response): void => {
  const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const success = PaymentService.cancelPaymentRequest(id);
  res.json({ success, message: success ? 'Payment request cancelled.' : 'Failed or payment not pending.' });
});

/**
 * GET /api/admin/transactions
 * List all transactions received from Android devices.
 */
adminRouter.get('/transactions', (req: Request, res: Response): void => {
  try {
    const limitStr = typeof req.query.limit === 'string' ? req.query.limit : '100';
    const limit = parseInt(limitStr, 10);
    const transactions = MatchingService.listTransactions(limit);
    res.json({ success: true, transactions });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch transactions.' });
  }
});

/**
 * GET /api/admin/devices
 * List all registered Android devices.
 */
adminRouter.get('/devices', (req: Request, res: Response): void => {
  try {
    const devices = DeviceService.listDevices();
    res.json({ success: true, devices });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch devices.' });
  }
});

/**
 * POST /api/admin/devices/:id/revoke
 * Revokes a device.
 */
adminRouter.post('/devices/:id/revoke', (req: Request, res: Response): void => {
  try {
    const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
    const success = DeviceService.revokeDevice(id);
    res.json({ success, message: success ? 'Device revoked successfully.' : 'Device not found or already inactive.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to revoke device.' });
  }
});

/**
 * POST /api/admin/simulate-sms
 * Allows simulating an incoming SMS from the admin dashboard for testing.
 */
adminRouter.post('/simulate-sms', async (req: Request, res: Response): Promise<void> => {
  try {
    const { raw_sms, amount, rrn } = req.body;
    if (!raw_sms && !amount) {
      res.status(400).json({ error: 'Either raw_sms or amount is required.' });
      return;
    }

    const result = await MatchingService.processTransaction({
      raw_sms: raw_sms || `Rs. ${amount} received on ${new Date().toISOString()} RRN#${rrn || '999888777666'} - Test SMS`,
      amount,
      rrn,
      sender: 'Admin Simulator'
    });

    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to simulate SMS transaction.' });
  }
});

/**
 * GET /api/admin/logs
 * Audit logs listing.
 */
adminRouter.get('/logs', (req: Request, res: Response): void => {
  try {
    const stmt = db.prepare(`SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 100`);
    const logs = stmt.all();
    res.json({ success: true, logs });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch audit logs.' });
  }
});
