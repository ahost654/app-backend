import { Router, Request, Response, NextFunction } from 'express';
import { PaymentService } from '../services/paymentService';
import { DeviceService } from '../services/deviceService';
import { MatchingService } from '../services/matchingService';
import { parseBankSms } from '../utils/smsParser';

export const apiRouter = Router();

/**
 * Middleware: Authenticates Android device via Bearer token
 */
export function requireDeviceAuth(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Unauthorized: Missing or invalid Authorization header.' });
    return;
  }

  const token = authHeader.split(' ')[1];
  const device = DeviceService.authenticateDevice(token);

  if (!device) {
    res.status(401).json({ error: 'Unauthorized: Invalid or revoked device token.' });
    return;
  }

  (req as any).device = device;
  next();
}

/**
 * POST /api/payments
 * Creates a new payment request.
 */
apiRouter.post('/payments', async (req: Request, res: Response): Promise<void> => {
  try {
    const { amount, orderId, note, successUrl } = req.body;
    if (!amount || isNaN(Number(amount))) {
      res.status(400).json({ error: 'Invalid or missing amount field.' });
      return;
    }

    let validatedSuccessUrl: URL | undefined;
    if (successUrl !== undefined) {
      try {
        validatedSuccessUrl = new URL(successUrl);
        if (!['http:', 'https:'].includes(validatedSuccessUrl.protocol)) {
          throw new Error('Invalid protocol');
        }
      } catch {
        res.status(400).json({ error: 'successUrl must be a valid absolute HTTP or HTTPS URL.' });
        return;
      }
    }

    const paymentRequest = await PaymentService.createPaymentRequest(amount, orderId, note);
    const paymentUrl = new URL(
      `/checkout/${encodeURIComponent(paymentRequest.order_id)}`,
      `${req.protocol}://${req.get('host')}`
    );
    if (validatedSuccessUrl) {
      paymentUrl.searchParams.set('success_url', validatedSuccessUrl.toString());
    }

    res.status(201).json({ success: true, payment: paymentRequest, paymentUrl: paymentUrl.toString() });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to create payment request.' });
  }
});

/**
 * GET /api/payments/:orderId
 * Fetches status of a payment request for checkout page.
 */
apiRouter.get('/payments/:orderId', async (req: Request, res: Response): Promise<void> => {
  try {
    const orderId = Array.isArray(req.params.orderId) ? req.params.orderId[0] : req.params.orderId;
    const payment = await PaymentService.getPaymentRequest(orderId);

    if (!payment) {
      res.status(404).json({ error: 'Payment request not found.' });
      return;
    }

    res.json({ success: true, payment });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error fetching payment request.' });
  }
});

/**
 * POST /api/device/pair
 * Pairs an Android device with pairing secret code and returns device token.
 */
apiRouter.post('/device/pair', (req: Request, res: Response): void => {
  try {
    const { deviceName, pairingSecret } = req.body;
    if (!pairingSecret) {
      res.status(400).json({ error: 'Pairing secret code is required.' });
      return;
    }

    const result = DeviceService.registerDevice(deviceName || 'Android Device', pairingSecret);
    res.status(201).json({
      success: true,
      message: 'Device paired successfully.',
      deviceId: result.deviceId,
      deviceToken: result.deviceToken
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Device pairing failed.' });
  }
});

/**
 * POST /api/device/ping
 * Heartbeat check for Android app.
 */
apiRouter.post('/device/ping', requireDeviceAuth, (req: Request, res: Response): void => {
  const device = (req as any).device;
  res.json({
    success: true,
    status: 'ONLINE',
    deviceId: device.id,
    deviceName: device.device_name,
    timestamp: new Date().toISOString()
  });
});

/**
 * POST /api/transactions
 * Secure endpoint for Android application to send parsed SMS transaction info.
 */
apiRouter.post('/transactions', requireDeviceAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const device = (req as any).device;
    const {
      amount,
      amount_paise,
      transaction_date,
      transaction_time,
      rrn,
      upi_reference,
      sender,
      raw_sms
    } = req.body;

    if (!raw_sms && amount === undefined && amount_paise === undefined) {
      res.status(400).json({ error: 'Transaction requires either raw_sms or valid amount.' });
      return;
    }

    const result = await MatchingService.processTransaction({
      amount,
      amount_paise,
      transaction_date,
      transaction_time,
      rrn,
      upi_reference,
      sender,
      raw_sms,
      device_id: device.id
    });

    res.status(200).json(result);
  } catch (err: any) {
    console.error('Error processing transaction:', err);
    res.status(500).json({ error: err.message || 'Transaction processing failed.' });
  }
});

/**
 * POST /api/test/parse-sms
 * Utility endpoint to test raw SMS parsing format without creating a transaction.
 */
apiRouter.post('/test/parse-sms', (req: Request, res: Response): void => {
  const { raw_sms } = req.body;
  if (!raw_sms) {
    res.status(400).json({ error: 'raw_sms is required.' });
    return;
  }

  const parsed = parseBankSms(raw_sms);
  res.json({
    success: true,
    parsed: parsed || 'Failed to parse SMS pattern.'
  });
});
