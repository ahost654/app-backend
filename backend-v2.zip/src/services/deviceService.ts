import { db } from '../db/database';
import { config } from '../config';
import crypto from 'crypto';

export interface DeviceRecord {
  id: string;
  device_name: string;
  device_token_hash: string;
  created_at: string;
  last_seen: string | null;
  is_active: number;
}

export class DeviceService {
  /**
   * Hashes a raw token with SHA-256 for secure DB comparison.
   */
  public static hashToken(token: string): string {
    return crypto.createHash('sha256').update(token).digest('hex');
  }

  /**
   * Registers a new device using the pairing secret.
   * Returns the plain token (to be sent ONCE to the device).
   */
  public static registerDevice(deviceName: string, pairingSecret: string): { deviceId: string; deviceToken: string } {
    if (pairingSecret !== config.pairingSecret) {
      throw new Error('Invalid pairing secret code.');
    }

    const deviceId = crypto.randomUUID();
    const deviceToken = `dev_tok_${crypto.randomBytes(32).toString('hex')}`;
    const tokenHash = this.hashToken(deviceToken);
    const createdAtIso = new Date().toISOString();

    const stmt = db.prepare(`
      INSERT INTO devices (id, device_name, device_token_hash, created_at, last_seen, is_active)
      VALUES (?, ?, ?, ?, ?, 1)
    `);

    stmt.run(deviceId, deviceName || 'Android Device', tokenHash, createdAtIso, createdAtIso);

    // Audit log
    db.prepare(`
      INSERT INTO audit_logs (id, action, details, created_at)
      VALUES (?, ?, ?, ?)
    `).run(
      crypto.randomUUID(),
      'REGISTER_DEVICE',
      JSON.stringify({ deviceId, deviceName }),
      createdAtIso
    );

    return { deviceId, deviceToken };
  }

  /**
   * Authenticates a device by its Bearer device token.
   */
  public static authenticateDevice(token: string): DeviceRecord | null {
    if (!token) return null;

    const tokenHash = this.hashToken(token);
    const stmt = db.prepare<[string], DeviceRecord>(`
      SELECT * FROM devices WHERE device_token_hash = ? AND is_active = 1
    `);

    const device = stmt.get(tokenHash);
    if (!device) return null;

    // Update last_seen timestamp asynchronously
    const nowIso = new Date().toISOString();
    db.prepare(`UPDATE devices SET last_seen = ? WHERE id = ?`).run(nowIso, device.id);

    return { ...device, last_seen: nowIso };
  }

  /**
   * Revokes a device.
   */
  public static revokeDevice(deviceId: string): boolean {
    const stmt = db.prepare(`UPDATE devices SET is_active = 0 WHERE id = ?`);
    const res = stmt.run(deviceId);

    // Audit log
    db.prepare(`
      INSERT INTO audit_logs (id, action, details, created_at)
      VALUES (?, ?, ?, ?)
    `).run(
      crypto.randomUUID(),
      'REVOKE_DEVICE',
      JSON.stringify({ deviceId }),
      new Date().toISOString()
    );

    return res.changes > 0;
  }

  /**
   * Lists all devices for Admin Panel.
   */
  public static listDevices(): DeviceRecord[] {
    const stmt = db.prepare<[], DeviceRecord>(`
      SELECT id, device_name, created_at, last_seen, is_active 
      FROM devices 
      ORDER BY created_at DESC
    `);
    return stmt.all();
  }
}
