import { db } from '../db/database';
import { PaymentService } from './paymentService';
import { parseBankSms, ParsedSms } from '../utils/smsParser';
import { toPaise } from '../utils/paiseConverter';
import crypto from 'crypto';
import { EventEmitter } from 'events';

export const sseEvents = new EventEmitter();

export interface ProcessTransactionInput {
  amount?: number;               // Rupees or paise
  amount_paise?: number;         // Explicit paise
  transaction_date?: string;
  transaction_time?: string;
  rrn?: string | null;
  upi_reference?: string | null;
  sender?: string | null;
  raw_sms: string;
  device_id?: string | null;
}

export interface MatchingResult {
  success: boolean;
  matched: boolean;
  isDuplicate: boolean;
  transactionId: string;
  matchedOrderId?: string | null;
  status: string;
  message: string;
}

export class MatchingService {
  /**
   * Processes an incoming transaction from an Android device or SMS payload.
   */
  public static async processTransaction(input: ProcessTransactionInput): Promise<MatchingResult> {
    const receivedAtIso = new Date().toISOString();
    const txnId = crypto.randomUUID();

    // 1. Ensure parsed SMS details
    let parsed: ParsedSms | null = null;
    if (input.raw_sms) {
      parsed = parseBankSms(input.raw_sms);
    }

    // Determine exact amount in integer paise
    let amountPaise = 0;
    if (parsed && parsed.amountPaise > 0) {
      amountPaise = parsed.amountPaise;
    } else if (input.amount !== undefined) {
      amountPaise = toPaise(input.amount);
    } else if (input.amount_paise) {
      amountPaise = input.amount_paise;
    }

    if (!amountPaise || amountPaise <= 0) {
      throw new Error('Unable to determine valid transaction amount from SMS or payload.');
    }

    const transactionDate = input.transaction_date || (parsed ? parsed.transactionDate : new Date().toISOString().split('T')[0]);
    const transactionTime = input.transaction_time || (parsed ? parsed.transactionTime : new Date().toTimeString().split(' ')[0]);
    const rrn = input.rrn || (parsed ? parsed.rrn : null);
    const upiReference = input.upi_reference || (parsed ? parsed.upiReference : null);
    const sender = input.sender || (parsed ? parsed.sender : null);
    const rawSms = input.raw_sms || '';
    const deviceId = input.device_id || null;
    let validDeviceId: string | null = null;
    if (deviceId) {
      const devCheck = db.prepare(`SELECT id FROM devices WHERE id = ?`).get(deviceId);
      if (devCheck) validDeviceId = deviceId;
    }

    // 2. Duplicate Check (Idempotency)
    let isDuplicate = false;

    if (rrn && rrn.trim().length > 3) {
      const existingRrn = db.prepare(`SELECT id FROM transactions WHERE rrn = ? AND amount = ?`).get(rrn.trim(), amountPaise);
      if (existingRrn) isDuplicate = true;
    }

    if (!isDuplicate && upiReference && upiReference.trim().length > 3) {
      const existingRef = db.prepare(`SELECT id FROM transactions WHERE upi_reference = ? AND amount = ?`).get(upiReference.trim(), amountPaise);
      if (existingRef) isDuplicate = true;
    }

    if (!isDuplicate && rawSms) {
      const existingSms = db.prepare(`
        SELECT id FROM transactions 
        WHERE raw_sms = ? AND amount = ? AND datetime(received_at) > datetime('now', '-5 minutes')
      `).get(rawSms, amountPaise);
      if (existingSms) isDuplicate = true;
    }

    if (isDuplicate) {
      console.log(`[MatchingService] Duplicate transaction detected. RRN: ${rrn}, UPI Ref: ${upiReference}`);
      
      // Save duplicate record marked as is_duplicate = 1
      db.prepare(`
        INSERT INTO transactions (
          id, amount, transaction_date, transaction_time, rrn, upi_reference,
          sender, raw_sms, received_at, matched_payment_id, device_id, is_duplicate
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, 1)
      `).run(
        txnId, amountPaise, transactionDate, transactionTime,
        rrn, upiReference, sender, rawSms, receivedAtIso, validDeviceId
      );

      return {
        success: true,
        matched: false,
        isDuplicate: true,
        transactionId: txnId,
        status: 'DUPLICATE_IGNORED',
        message: 'Duplicate transaction received and ignored.'
      };
    }

    // 3. Expire old pending payment requests before matching
    PaymentService.expirePendingOrders();

    // 4. Primary Exact Integer Amount Matching
    // Query PENDING orders matching payable_amount exact match
    const pendingOrders = db.prepare(`
      SELECT * FROM payment_requests 
      WHERE payable_amount = ? AND status = 'PENDING'
      ORDER BY created_at ASC
    `).all(amountPaise) as any[];

    const nowMs = Date.now();
    const matchedOrder = pendingOrders.find(o => new Date(o.expires_at).getTime() > nowMs);

    let matchedPaymentId: string | null = null;
    let resultStatus = 'UNMATCHED';
    let resultMessage = 'Transaction recorded. No matching active pending payment request found.';

    if (matchedOrder) {
      matchedPaymentId = matchedOrder.id;
      resultStatus = 'MATCHED_PAID';
      resultMessage = `Payment matched successfully with Order ID ${matchedOrder.order_id}!`;
    } else {
      // Check if there was an expired request for this exact amount
      const expiredOrderStmt = db.prepare(`
        SELECT order_id FROM payment_requests 
        WHERE payable_amount = ? AND status = 'EXPIRED' 
        ORDER BY expires_at DESC LIMIT 1
      `);
      const expiredOrder = expiredOrderStmt.get(amountPaise) as any;
      if (expiredOrder) {
        resultStatus = 'EXPIRED_ORDER_LATE_PAYMENT';
        resultMessage = `Transaction amount matches expired Order ID ${expiredOrder.order_id}. Recorded separately without updating expired order status.`;
      }
    }

    // 5. Insert transaction into DB FIRST (so transactions.id exists for payment_requests foreign key)
    db.prepare(`
      INSERT INTO transactions (
        id, amount, transaction_date, transaction_time, rrn, upi_reference,
        sender, raw_sms, received_at, matched_payment_id, device_id, is_duplicate
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
    `).run(
      txnId, amountPaise, transactionDate, transactionTime,
      rrn, upiReference, sender, rawSms, receivedAtIso, matchedPaymentId, validDeviceId
    );

    // 6. If payment matched, update payment_request status to PAID SECOND
    if (matchedOrder) {
      db.prepare(`
        UPDATE payment_requests 
        SET status = 'PAID', paid_at = ?, transaction_id = ? 
        WHERE id = ?
      `).run(receivedAtIso, txnId, matchedOrder.id);

      console.log(`[MatchingService] SUCCESS: Order ${matchedOrder.order_id} marked as PAID via Txn ${txnId}`);
    }

    // 7. Audit Logging
    db.prepare(`
      INSERT INTO audit_logs (id, action, details, created_at)
      VALUES (?, ?, ?, ?)
    `).run(
      crypto.randomUUID(),
      matchedPaymentId ? 'PAYMENT_MATCHED' : 'UNMATCHED_TRANSACTION_RECEIVED',
      JSON.stringify({ txnId, amountPaise, rrn, matchedOrderId: matchedOrder ? matchedOrder.order_id : null }),
      receivedAtIso
    );

    // 7. Emit real-time SSE event
    sseEvents.emit('transaction_processed', {
      transactionId: txnId,
      matchedOrderId: matchedOrder ? matchedOrder.order_id : null,
      status: resultStatus,
      amountPaise,
      rrn,
      receivedAt: receivedAtIso
    });

    if (matchedOrder) {
      sseEvents.emit(`order_updated:${matchedOrder.order_id}`, {
        orderId: matchedOrder.order_id,
        status: 'PAID',
        paidAt: receivedAtIso,
        rrn
      });
    }

    return {
      success: true,
      matched: !!matchedOrder,
      isDuplicate: false,
      transactionId: txnId,
      matchedOrderId: matchedOrder ? matchedOrder.order_id : null,
      status: resultStatus,
      message: resultMessage
    };
  }

  /**
   * Lists all transactions for Admin Panel.
   */
  public static listTransactions(limit: number = 100): any[] {
    const stmt = db.prepare(`
      SELECT t.*, d.device_name, p.order_id as matched_order_id
      FROM transactions t
      LEFT JOIN devices d ON t.device_id = d.id
      LEFT JOIN payment_requests p ON t.matched_payment_id = p.id
      ORDER BY t.received_at DESC
      LIMIT ?
    `);
    return stmt.all(limit);
  }
}
