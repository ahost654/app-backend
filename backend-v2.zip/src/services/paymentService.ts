import { db } from '../db/database';
import { config, getActiveMerchantUpiId, getActiveMerchantName } from '../config';
import { toPaise, toRupeesString, formatCurrency } from '../utils/paiseConverter';
import { generateUpiUrl, generateQrCodeDataUrl } from '../utils/upiGenerator';
import crypto from 'crypto';

export interface PaymentRequestRecord {
  id: string;
  order_id: string;
  base_amount: number;         // paise
  verification_amount: number; // paise
  payable_amount: number;      // paise
  upi_url: string;
  status: 'PENDING' | 'PAID' | 'EXPIRED' | 'FAILED' | 'CANCELLED';
  created_at: string;
  expires_at: string;
  paid_at: string | null;
  transaction_id: string | null;
}

export interface PaymentResponseDto extends PaymentRequestRecord {
  merchantUpiId: string;
  baseAmountRupees: number;
  verificationAmountRupees: number;
  payableAmountRupees: number;
  baseAmountFormatted: string;
  payableAmountFormatted: string;
  qrCodeDataUrl?: string;
  timeRemainingSeconds: number;
}

export class PaymentService {
  /**
   * Automatically updates any PENDING orders whose expires_at is past the current time.
   */
  public static expirePendingOrders(): number {
    const nowIso = new Date().toISOString();
    const stmt = db.prepare(`
      UPDATE payment_requests 
      SET status = 'EXPIRED' 
      WHERE status = 'PENDING' AND datetime(expires_at) <= datetime(?)
    `);
    const result = stmt.run(nowIso);
    if (result.changes > 0) {
      console.log(`[PaymentService] Expired ${result.changes} pending payment request(s).`);
    }
    return result.changes;
  }

  /**
   * Generates a unique decimal verification amount (1..99 paise) for the given base amount.
   */
  private static allocateVerificationDecimal(baseAmountPaise: number): number {
    // 1. Clean up expired orders first
    this.expirePendingOrders();

    // 2. Fetch currently reserved verification decimals for this base amount among active PENDING orders
    const nowIso = new Date().toISOString();
    const stmt = db.prepare<[number, string], { verification_amount: number }>(`
      SELECT verification_amount 
      FROM payment_requests 
      WHERE base_amount = ? 
        AND status = 'PENDING' 
        AND datetime(expires_at) > datetime(?)
    `);
    
    const activeDecimals = stmt.all(baseAmountPaise, nowIso).map(row => row.verification_amount);
    const activeSet = new Set(activeDecimals);

    // 3. Find an available decimal from 1 to 99 paise
    const availableDecimals: number[] = [];
    for (let d = 1; d <= 99; d++) {
      if (!activeSet.has(d)) {
        availableDecimals.push(d);
      }
    }

    if (availableDecimals.length === 0) {
      throw new Error(`All 99 verification decimals are currently in use for base amount ₹${toRupeesString(baseAmountPaise)}. Please wait for pending requests to complete or expire.`);
    }

    // Pick a pseudo-random or sequentially distributed decimal from available
    const randomIndex = Math.floor(Math.random() * availableDecimals.length);
    return availableDecimals[randomIndex];
  }

  /**
   * Creates a new UPI payment request.
   */
  public static async createPaymentRequest(
    baseAmountInput: number | string,
    customOrderId?: string,
    note?: string
  ): Promise<PaymentResponseDto> {
    const baseAmountPaise = toPaise(baseAmountInput);

    if (baseAmountPaise <= 0) {
      throw new Error('Payment amount must be greater than zero.');
    }

    // Allocate decimal verification amount (in paise)
    const verificationAmountPaise = this.allocateVerificationDecimal(baseAmountPaise);
    const payableAmountPaise = baseAmountPaise + verificationAmountPaise;

    // Generate Order ID
    const orderId = customOrderId || `ORD-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`;
    const id = crypto.randomUUID();

    // Timestamps
    const now = new Date();
    const expiresAt = new Date(now.getTime() + config.expirationMinutes * 60 * 1000);

    const createdAtIso = now.toISOString();
    const expiresAtIso = expiresAt.toISOString();

    const activeUpiId = getActiveMerchantUpiId();
    const activeMerchantName = getActiveMerchantName();

    // Generate UPI Payment Link
    const upiUrl = generateUpiUrl({
      merchantUpiId: activeUpiId,
      merchantName: activeMerchantName,
      amountPaise: payableAmountPaise,
      orderId: orderId,
      note: note || `Payment for ${orderId}`
    });

    // Save to Database
    const insertStmt = db.prepare(`
      INSERT INTO payment_requests (
        id, order_id, base_amount, verification_amount, payable_amount,
        upi_url, status, created_at, expires_at
      ) VALUES (?, ?, ?, ?, ?, ?, 'PENDING', ?, ?)
    `);

    insertStmt.run(
      id,
      orderId,
      baseAmountPaise,
      verificationAmountPaise,
      payableAmountPaise,
      upiUrl,
      createdAtIso,
      expiresAtIso
    );

    // Audit log
    db.prepare(`
      INSERT INTO audit_logs (id, action, details, created_at)
      VALUES (?, ?, ?, ?)
    `).run(
      crypto.randomUUID(),
      'CREATE_PAYMENT_REQUEST',
      JSON.stringify({ orderId, baseAmountPaise, payableAmountPaise, expiresAtIso }),
      createdAtIso
    );

    return this.formatPaymentResponse({
      id,
      order_id: orderId,
      base_amount: baseAmountPaise,
      verification_amount: verificationAmountPaise,
      payable_amount: payableAmountPaise,
      upi_url: upiUrl,
      status: 'PENDING',
      created_at: createdAtIso,
      expires_at: expiresAtIso,
      paid_at: null,
      transaction_id: null
    });
  }

  /**
   * Retrieves a payment request by Order ID or DB UUID.
   */
  public static async getPaymentRequest(orderIdOrId: string): Promise<PaymentResponseDto | null> {
    this.expirePendingOrders();

    const stmt = db.prepare<[string, string], PaymentRequestRecord>(`
      SELECT * FROM payment_requests WHERE order_id = ? OR id = ?
    `);

    const record = stmt.get(orderIdOrId, orderIdOrId);
    if (!record) return null;

    return this.formatPaymentResponse(record);
  }

  /**
   * Lists all payment requests for Admin Dashboard.
   */
  public static async listPaymentRequests(status?: string, limit: number = 100): Promise<PaymentResponseDto[]> {
    this.expirePendingOrders();

    let sql = `SELECT * FROM payment_requests`;
    const params: any[] = [];

    if (status && status !== 'ALL') {
      sql += ` WHERE status = ?`;
      params.push(status);
    }

    sql += ` ORDER BY created_at DESC LIMIT ?`;
    params.push(limit);

    const stmt = db.prepare(sql);
    const records = stmt.all(...params) as PaymentRequestRecord[];

    return Promise.all(records.map(rec => this.formatPaymentResponse(rec)));
  }

  /**
   * Cancels a pending payment request manually.
   */
  public static cancelPaymentRequest(orderIdOrId: string): boolean {
    const stmt = db.prepare(`
      UPDATE payment_requests 
      SET status = 'CANCELLED' 
      WHERE (order_id = ? OR id = ?) AND status = 'PENDING'
    `);
    const res = stmt.run(orderIdOrId, orderIdOrId);
    return res.changes > 0;
  }

  /**
   * Helper to format DB record into DTO with rupees, formatted currency, QR code Data URL, and remaining time.
   */
  public static async formatPaymentResponse(record: PaymentRequestRecord): Promise<PaymentResponseDto> {
    const activeUpiId = getActiveMerchantUpiId();
    const activeMerchantName = getActiveMerchantName();

    // Dynamically regenerate UPI URL using active merchant UPI ID so changing config or setting instantly updates all UPI URLs and QR codes
    const activeUpiUrl = generateUpiUrl({
      merchantUpiId: activeUpiId,
      merchantName: activeMerchantName,
      amountPaise: record.payable_amount,
      orderId: record.order_id
    });

    const qrCodeDataUrl = await generateQrCodeDataUrl(activeUpiUrl);
    
    const now = new Date().getTime();
    const expiresAtMs = new Date(record.expires_at).getTime();
    const timeRemainingSeconds = Math.max(0, Math.floor((expiresAtMs - now) / 1000));

    return {
      ...record,
      merchantUpiId: activeUpiId,
      upi_url: activeUpiUrl,
      baseAmountRupees: record.base_amount / 100,
      verificationAmountRupees: record.verification_amount / 100,
      payableAmountRupees: record.payable_amount / 100,
      baseAmountFormatted: formatCurrency(record.base_amount),
      payableAmountFormatted: formatCurrency(record.payable_amount),
      qrCodeDataUrl,
      timeRemainingSeconds
    };
  }
}
