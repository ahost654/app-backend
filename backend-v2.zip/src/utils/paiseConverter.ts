/**
 * Converts a rupees value (number or string, e.g., 100.37, "100.37", "100") to integer paise.
 * 100.37 -> 10037 paise.
 * Prevents floating point errors.
 */
export function toPaise(val: number | string): number {
  if (typeof val === 'number') {
    return Math.round(val * 100);
  }
  const str = val.trim().replace(/,/g, '');
  if (!str) return 0;
  const parts = str.split('.');
  const rupees = parseInt(parts[0] || '0', 10);
  let paise = 0;
  if (parts.length > 1) {
    const rawPaiseStr = (parts[1] + '00').substring(0, 2);
    paise = parseInt(rawPaiseStr, 10);
  }
  return (rupees * 100) + (isNaN(paise) ? 0 : paise);
}

/**
 * Converts integer paise back to a formatted rupees string (e.g. 10037 -> "100.37").
 */
export function toRupeesString(paise: number): string {
  const rupees = Math.floor(paise / 100);
  const remainder = Math.abs(paise % 100);
  const paiseStr = remainder < 10 ? `0${remainder}` : `${remainder}`;
  return `${rupees}.${paiseStr}`;
}

/**
 * Formats integer paise as INR currency (e.g. 10037 -> "₹100.37").
 */
export function formatCurrency(paise: number): string {
  return `₹${toRupeesString(paise)}`;
}
