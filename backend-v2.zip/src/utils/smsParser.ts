import { toPaise } from './paiseConverter';

export interface ParsedSms {
  amountPaise: number;
  amountRupees: number;
  transactionDate: string; // YYYY-MM-DD
  transactionTime: string; // HH:MM:SS
  rrn: string | null;
  upiReference: string | null;
  sender: string | null;
  rawSms: string;
  isCredit: boolean;
}

export function parseBankSms(rawSms: string): ParsedSms | null {
  if (!rawSms || typeof rawSms !== 'string') return null;

  const sms = rawSms.trim();

  // Basic credit check: must indicate credit/received/credited
  const isCreditPattern = /(received|credited|credited to|credited with|credit|recvd|added)/i;
  const isDebitPattern = /(debited|sent|paid|transfer to|deducted)/i;
  
  if (isDebitPattern.test(sms) && !isCreditPattern.test(sms)) {
    return null; // Ignore debits
  }

  // 1. Amount Extraction
  // Matches Rs. 100.37, Rs 100.37, INR 100.37, Rs.100.37, INR 100.37/- etc.
  const amountRegex = /(?:Rs\.?|INR|\u20B9)\s*([0-9]+(?:\.[0-9]{1,2})?)/i;
  const amountMatch = sms.match(amountRegex);
  
  if (!amountMatch) {
    return null; // Cannot determine amount
  }

  const amountRupeesStr = amountMatch[1];
  const amountRupees = parseFloat(amountRupeesStr);
  const amountPaise = toPaise(amountRupeesStr);

  // 2. Date & Time Extraction
  // Formats: 29-09-2026 13:14:49, 29/09/2026 13:14:49, 01-Oct-26, 01Oct26 etc.
  let transactionDate = new Date().toISOString().split('T')[0]; // fallback today
  let transactionTime = new Date().toTimeString().split(' ')[0]; // fallback now

  const dateTimeRegex = /([0-9]{2}[-\/][0-9]{2}[-\/][0-9]{4})\s+([0-9]{2}:[0-9]{2}:[0-9]{2})/i;
  const dateTimeMatch = sms.match(dateTimeRegex);

  if (dateTimeMatch) {
    const rawDate = dateTimeMatch[1]; // DD-MM-YYYY
    const dateParts = rawDate.split(/[-\/]/);
    if (dateParts.length === 3) {
      // Convert DD-MM-YYYY to YYYY-MM-DD
      transactionDate = `${dateParts[2]}-${dateParts[1].padStart(2, '0')}-${dateParts[0].padStart(2, '0')}`;
    }
    transactionTime = dateTimeMatch[2];
  } else {
    // Try single date pattern DD-MM-YYYY or DD-Mon-YY
    const dateOnlyRegex = /([0-9]{2}[-\/][0-9]{2}[-\/][0-9]{2,4})/i;
    const dateMatch = sms.match(dateOnlyRegex);
    if (dateMatch) {
      const parts = dateMatch[1].split(/[-\/]/);
      if (parts.length === 3) {
        let year = parts[2];
        if (year.length === 2) year = `20${year}`;
        transactionDate = `${year}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
      }
    }
  }

  // 3. RRN (Retrieval Reference Number) Extraction
  // RRN#663857923727, RRN 663857923727, Ref no 663857923727, Ref#663857923727, UPI Ref 663857923727
  const rrnRegex = /(?:RRN[#:\s]*|Ref[#:\s]*|Ref\s+no[#:\s]*|UPI\s+Ref[#:\s]*)([0-9]{12})/i;
  const rrnMatch = sms.match(rrnRegex);
  let rrn: string | null = rrnMatch ? rrnMatch[1] : null;

  // 4. UPI Reference ID / Transaction ID Extraction
  // BQR-UPI/0373270109100116100020085363087/karthik... or UPI/T260928...
  const upiRefRegex = /(?:BQR-UPI|UPI|Txn)\/([A-Za-z0-9]+)/i;
  const upiRefMatch = sms.match(upiRefRegex);
  let upiReference: string | null = upiRefMatch ? upiRefMatch[1] : null;

  // Fallback: if no RRN found with explicit label, look for any 12-digit number sequence
  if (!rrn) {
    const standalone12Digit = sms.match(/\b([0-9]{12})\b/);
    if (standalone12Digit) {
      rrn = standalone12Digit[1];
    }
  }

  // 5. Sender / Provider Extraction
  // E.g., "- Worldline India", "from ICICI", "from SBI", etc.
  let sender: string | null = null;
  const senderDashMatch = sms.match(/-\s*([A-Za-z0-9\s]+)$/);
  if (senderDashMatch) {
    sender = senderDashMatch[1].trim();
  } else if (sms.toLowerCase().includes('worldline')) {
    sender = 'Worldline India';
  } else if (sms.toLowerCase().includes('icici')) {
    sender = 'ICICI Bank';
  } else if (sms.toLowerCase().includes('hdfc')) {
    sender = 'HDFC Bank';
  } else if (sms.toLowerCase().includes('sbi')) {
    sender = 'SBI';
  } else if (sms.toLowerCase().includes('axis')) {
    sender = 'Axis Bank';
  }

  return {
    amountPaise,
    amountRupees,
    transactionDate,
    transactionTime,
    rrn,
    upiReference,
    sender,
    rawSms: sms,
    isCredit: true
  };
}
