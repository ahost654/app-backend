import QRCode from 'qrcode';
import { toRupeesString } from './paiseConverter';

export interface UpiLinkOptions {
  merchantUpiId: string;
  merchantName: string;
  amountPaise: number;
  orderId: string;
  note?: string;
}

export function generateUpiUrl(options: UpiLinkOptions): string {
  const { merchantUpiId, merchantName, amountPaise, orderId, note } = options;
  const formattedAmount = toRupeesString(amountPaise);
  
  const params = new URLSearchParams({
    pa: merchantUpiId,
    pn: merchantName,
    am: formattedAmount,
    cu: 'INR',
    tn: note || orderId
  });

  return `upi://pay?${params.toString()}`;
}

export async function generateQrCodeDataUrl(upiUrl: string): Promise<string> {
  try {
    return await QRCode.toDataURL(upiUrl, {
      errorCorrectionLevel: 'M',
      margin: 2,
      width: 320,
      color: {
        dark: '#0f172a',
        light: '#ffffff'
      }
    });
  } catch (err) {
    console.error('Failed to generate QR Code:', err);
    throw err;
  }
}
