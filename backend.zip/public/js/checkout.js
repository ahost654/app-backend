let currentPaymentData = null;
let timerInterval = null;
let sseSource = null;

function getOrderIdFromUrl() {
  const pathParts = window.location.pathname.split('/');
  if (pathParts.length > 2 && pathParts[1] === 'checkout') {
    return pathParts[2];
  }
  const params = new URLSearchParams(window.location.search);
  return params.get('order_id') || params.get('id');
}

async function initCheckout() {
  const orderId = getOrderIdFromUrl();
  if (!orderId) {
    document.getElementById('loadingState').innerHTML = `<p style="color: var(--danger);">Error: No Order ID provided in URL.</p>`;
    return;
  }

  try {
    const res = await fetch(`/api/payments/${orderId}`);
    const data = await res.json();

    if (!data.success || !data.payment) {
      document.getElementById('loadingState').innerHTML = `<p style="color: var(--danger);">Order not found or expired.</p>`;
      return;
    }

    currentPaymentData = data.payment;
    renderPaymentDetails(data.payment);

    // Setup SSE connection for real-time order update
    setupSse(orderId);

  } catch (err) {
    console.error('Failed to load payment details:', err);
    document.getElementById('loadingState').innerHTML = `<p style="color: var(--danger);">Error loading payment information.</p>`;
  }
}

function renderPaymentDetails(p) {
  document.getElementById('loadingState').style.display = 'none';
  document.getElementById('paymentDetails').style.display = 'block';

  document.getElementById('orderIdText').textContent = p.order_id;
  if (document.getElementById('merchantUpiVpaText')) {
    document.getElementById('merchantUpiVpaText').textContent = p.merchantUpiId || '10011@AXISBANK';
  }
  document.getElementById('payableAmountText').textContent = p.payableAmountFormatted;
  document.getElementById('exactAmountAlertText').textContent = p.payableAmountFormatted;
  document.getElementById('verificationDecimalText').textContent = `₹${p.verificationAmountRupees.toFixed(2)}`;

  document.getElementById('baseAmountText').textContent = p.baseAmountFormatted;
  document.getElementById('verificationAmountBreakdown').textContent = `+ ₹${p.verificationAmountRupees.toFixed(2)}`;
  document.getElementById('totalPayableBreakdown').textContent = p.payableAmountFormatted;

  document.getElementById('qrCodeImg').src = p.qrCodeDataUrl;
  document.getElementById('openUpiAppBtn').href = p.upi_url;

  const createdDate = new Date(p.created_at);
  const expiresDate = new Date(p.expires_at);
  document.getElementById('createdAtText').textContent = createdDate.toLocaleTimeString();
  document.getElementById('expiresAtText').textContent = expiresDate.toLocaleTimeString();

  updateStatusBadge(p.status);

  // Start countdown if pending
  if (p.status === 'PENDING') {
    startCountdown(p.expires_at);
  } else {
    document.getElementById('countdownTimer').textContent = '00:00';
  }
}

function updateStatusBadge(status) {
  const badge = document.getElementById('statusBadge');
  badge.textContent = status;
  badge.className = 'badge';

  if (status === 'PENDING') {
    badge.classList.add('badge-pending');
  } else if (status === 'PAID') {
    badge.classList.add('badge-paid');
    badge.innerHTML = '✓ PAYMENT SUCCESSFUL';
    showPaymentSuccessView();
  } else if (status === 'EXPIRED') {
    badge.classList.add('badge-expired');
    badge.innerHTML = '⏱️ PAYMENT EXPIRED';
    showExpiredView();
  } else {
    badge.classList.add('badge-failed');
  }
}

function startCountdown(expiresAtIso) {
  if (timerInterval) clearInterval(timerInterval);

  const expiresTime = new Date(expiresAtIso).getTime();

  function tick() {
    const now = new Date().getTime();
    const diff = Math.max(0, Math.floor((expiresTime - now) / 1000));

    const minutes = Math.floor(diff / 60);
    const seconds = diff % 60;
    const formatted = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

    const timerEl = document.getElementById('countdownTimer');
    timerEl.textContent = formatted;

    if (diff <= 0) {
      clearInterval(timerInterval);
      updateStatusBadge('EXPIRED');
    }
  }

  tick();
  timerInterval = setInterval(tick, 1000);
}

function setupSse(orderId) {
  if (sseSource) sseSource.close();

  sseSource = new EventSource(`/api/sse/payments/${orderId}`);

  sseSource.addEventListener('order_update', (event) => {
    const data = JSON.parse(event.data);
    console.log('[SSE] Order Update Event:', data);
    if (data.status === 'PAID') {
      if (timerInterval) clearInterval(timerInterval);
      updateStatusBadge('PAID');
      showToast('Payment verified successfully!');
    }
  });

  sseSource.onerror = (err) => {
    console.warn('[SSE] Connection error, falling back to polling...', err);
    // Poll every 4 seconds as fallback
    setTimeout(() => pollPaymentStatus(orderId), 4000);
  };
}

async function pollPaymentStatus(orderId) {
  try {
    const res = await fetch(`/api/payments/${orderId}`);
    const data = await res.json();
    if (data.success && data.payment) {
      if (data.payment.status !== 'PENDING') {
        updateStatusBadge(data.payment.status);
      }
    }
  } catch (err) {
    console.error('Polling error:', err);
  }
}

function showPaymentSuccessView() {
  const card = document.getElementById('checkoutApp');
  card.style.borderColor = 'var(--success)';
  document.querySelector('.qr-wrapper').style.opacity = '0.3';
  document.getElementById('openUpiAppBtn').style.display = 'none';

  const alert = document.querySelector('.decimal-alert');
  alert.style.background = 'rgba(16, 185, 129, 0.15)';
  alert.style.borderColor = 'var(--success)';
  alert.style.color = 'var(--success)';
  alert.innerHTML = `<strong>Payment Verified!</strong> Thank you for your payment. Order completed.`;
}

function showExpiredView() {
  const card = document.getElementById('checkoutApp');
  card.style.borderColor = 'var(--neutral)';
  document.querySelector('.qr-wrapper').style.opacity = '0.2';
  document.getElementById('openUpiAppBtn').style.display = 'none';

  const alert = document.querySelector('.decimal-alert');
  alert.style.background = 'rgba(100, 116, 139, 0.15)';
  alert.style.borderColor = 'var(--neutral)';
  alert.style.color = 'var(--text-muted)';
  alert.innerHTML = `<strong>Session Expired:</strong> This payment link has expired after 5 minutes. Please generate a new payment link.`;
}

function copyUpiLink() {
  if (!currentPaymentData) return;
  navigator.clipboard.writeText(currentPaymentData.upi_url);
  showToast('UPI Link copied to clipboard!');
}

function showToast(msg) {
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = msg;
  document.body.appendChild(toast);

  setTimeout(() => toast.remove(), 3000);
}

document.addEventListener('DOMContentLoaded', initCheckout);
